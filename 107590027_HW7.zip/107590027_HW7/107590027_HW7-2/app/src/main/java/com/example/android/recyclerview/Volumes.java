package com.example.android.recyclerview;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;

import java.util.Arrays;
import java.util.LinkedList;

public class Volumes extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private  WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> Volumes = new LinkedList<String>(Arrays.asList(
            "蒜頭整顆去皮，薑切片，辣椒切片，九層塔去梗。\n"+
            "\n" +
            "透抽洗乾淨處理好，切成圈狀。透抽不要撕去表皮才會脆。 準備一鍋熱水，當水小滾時放入透抽，15秒後撈出，瀝乾水份備用。(透抽一定要先燙過，不然會水水的，因為透抽會出水)\n" +
            "\n" +
            "熱鍋後下黑麻油，薑片爆至邊緣有點焦焦的。\n" +
            "\n" +
            "再放入蒜頭及辣椒爆香。\n" +
            "\n" +
            "放入醬油、米酒和砂糖煮至滾。\n" +
            "\n"+
            "放入透抽翻炒一下，蓋上鍋蓋以中火燜煮1分半鐘讓透抽入味，掀開鍋蓋再翻炒一下避免底部焦掉，再蓋鍋蓋燜1分半鐘。(透抽不要煮超過5分鐘，會變透抽口香糖)\n" +
            "\n" +
            "最後放入九層塔和太白粉水拌炒一下即可。\n"

    ));
    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.recycleview);
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, Volumes);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById(R.id.imageView);
        image.setImageResource(R.drawable.volume);
    }
}



