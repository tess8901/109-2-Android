package com.example.android.recyclerview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;

import java.util.Arrays;
import java.util.LinkedList;

public class Soup extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private  WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> Soup = new LinkedList<String>(Arrays.asList(
                    "1. 用小火煮一鍋水並且加入適量的薑絲去煮。\n"+
                    "\n"+
                    "2. 將蔥切成蔥花。\n"+
                    "\n"+
                    "3. 將切好的蔥花放入碗中在碗中加入少許香油、鹽巴、白胡椒。\n"+
                    "\n"+
                    "4. 將蛋打散，並且滴入2滴白醋。\n"+
                    "\n"+
                    "5. 水滾了之後，加入紫菜。\n"+
                    "\n"+
                    "6. 紫菜滾了之後，加入蛋。\n"+
                    "\n"+
                    "7. 待加入蛋的湯滾了之後，即可倒入碗中就完成了一碗美味又好吃的紫菜蛋花湯了。\n"+
                    "\n"
    ));


    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.recycleview);
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this,Soup);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById(R.id.imageView);
        image.setImageResource(R.drawable.soup);
    }
}
