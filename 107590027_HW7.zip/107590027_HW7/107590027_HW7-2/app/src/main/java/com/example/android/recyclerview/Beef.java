package com.example.android.recyclerview;

        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.support.v7.widget.LinearLayoutManager;
        import android.support.v7.widget.RecyclerView;
        import android.widget.ImageView;

        import java.util.Arrays;
        import java.util.LinkedList;

public class Beef extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private  WordListAdapter mAdapter;
    private ImageView image;
    LinkedList<String> Beef = new LinkedList<String>(Arrays.asList(
            "1. 首先將牛肉絲與醃料均勻混合備用。\n"+
            "\n"+
            "2. 起油鍋先將牛肉絲下鍋炒製5分熟後起鍋備用。\n"+
            "\n"+
            "3. 另起油鍋，將薑絲、蒜、蔥白下鍋爆香。\n"+
            "\n"+
            "4. 再來將步驟2的牛肉絲與醬油、蠔油倒入鍋中拌炒。\n"+
            "\n"+
            "5. 最後將蔥綠、辣椒下鍋拌炒後，從鍋邊嗆入米酒就完成了喔。\n"
    ));

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.recycleview);
        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new WordListAdapter(this, Beef);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        image = findViewById(R.id.imageView);
        image.setImageResource(R.drawable.beef);
    }
}
