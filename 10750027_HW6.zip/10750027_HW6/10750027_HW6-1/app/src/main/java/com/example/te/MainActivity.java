package com.example.te;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CheckBox checkBox1;
    private CheckBox checkBox2;
    private CheckBox checkBox3;
    private CheckBox checkBox4;
    private CheckBox checkBox5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkBox1 = findViewById(R.id.checkBox);
        checkBox2 = findViewById(R.id.checkBox2);
        checkBox3 = findViewById(R.id.checkBox3);
        checkBox4 = findViewById(R.id.checkBox4);
        checkBox5 = findViewById(R.id.checkBox5);
    }

    public void show(View view) {
        String str = "Toppings:";
        if(checkBox1.isChecked()) str += getString(R.string.checkBox1) + " ";
        if(checkBox2.isChecked()) str += getString(R.string.checkBox2) + " ";
        if(checkBox3.isChecked()) str += getString(R.string.checkBox3) + " ";
        if(checkBox4.isChecked()) str += getString(R.string.checkBox4) + " ";
        if(checkBox5.isChecked()) str += getString(R.string.checkBox5) + " ";
        Toast.makeText(this, str, Toast.LENGTH_LONG).show();
    }

}
